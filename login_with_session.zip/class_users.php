<?php

class users {
    private $uname;
    private $pass;

    function __construct() {
        $this->uname="AA";
        $this->pass="BB";
    }

    public function IsValid($u,$p){
        if(($u==$this->uname)&&($p==$this->pass))
            return true;
        return false;
    }
}